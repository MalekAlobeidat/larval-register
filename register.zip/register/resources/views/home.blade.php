@extends('layout.master')

@section('malek')
    <p>helloooooooo user</p>
@endsection
