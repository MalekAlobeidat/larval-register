@extends('layout.master')

@section('malek')
    <p>helloooooooo admin</p>
    @endsection
