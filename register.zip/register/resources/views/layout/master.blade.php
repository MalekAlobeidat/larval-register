@include('layout.header')

@yield('malek')

@include('layout.footer')