@extends('layout.master')

@section('malek')
    <form action="{{ route('Login') }}" method="POST">
        @csrf
        <input type="email" name="email" placeholder="Email">
        <input type="text" name="password" placeholder="password">
        <button type="submit" >Submit</button>
    </form>
@endsection
