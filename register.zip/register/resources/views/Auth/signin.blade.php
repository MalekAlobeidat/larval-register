@extends('layout.master')

@section('malek')
<form action="{{ route('signin.store') }}" method="POST">
    @csrf
    <input type="text" name="name" placeholder="Nmae">
    <input type="email" name="email" placeholder="Email">
    <input type="text" name="password" placeholder="password">
    <input type="hidden" name="role_id" value="2" >
    <button type="submit" >Submit</button>
</form>    
@endsection
