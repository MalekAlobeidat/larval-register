<?php $__env->startSection('malek'); ?>
    <form action="<?php echo e(route('Login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Email">
        <input type="text" name="password" placeholder="password">
        <button type="submit" >Submit</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/malekalobeidat/Desktop/malek_larva;/register/resources/views/Auth/login.blade.php ENDPATH**/ ?>